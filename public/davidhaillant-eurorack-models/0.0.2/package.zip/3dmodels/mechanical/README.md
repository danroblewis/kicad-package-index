# kicad-3dmodels

M3 Hex Nut:

![M3 Hex Nut](https://github.com/dhaillant/kicad-3dmodels/raw/master/mechanical/M3-Hex-Nut.png)

M3x4 Philips Screw:

![M3x4 Philips Screw](https://github.com/dhaillant/kicad-3dmodels/raw/master/mechanical/M3x4-Screw.png)

M3x5.5x10 Hex Spacer:

![M3x5.5x10 Hex Spacer](https://github.com/dhaillant/kicad-3dmodels/raw/master/mechanical/M3x5.5x10-Spacer.png)

