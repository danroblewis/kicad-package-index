## IDC Connectors Vertical SMT

![IDC-Header_2x08_P2.54mm_Vertical_SMT](https://github.com/dhaillant/kicad-3dmodels/raw/master/Connector_IDC/IDC-Header_2x08_P2.54mm_Vertical_SMT.png)


Generated with https://github.com/dhaillant/kicad-3d-models-in-freecad

Dimensions based on https://datasheet.lcsc.com/lcsc/2006200334_JILN-321016MG0CBK00A03_C601969.pdf
