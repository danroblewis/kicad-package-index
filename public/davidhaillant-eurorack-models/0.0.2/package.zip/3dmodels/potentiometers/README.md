# kicad-3dmodels

ALPS 9mm, single turn, plastic shaft, vertical potentiometer RK09K:
![PTF/78](https://github.com/dhaillant/kicad-3dmodels/raw/master/potentiometers/ALPS-RK09K.png)
