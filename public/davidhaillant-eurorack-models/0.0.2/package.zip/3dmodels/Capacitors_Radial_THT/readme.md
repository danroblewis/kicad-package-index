## Realistic Height Electrolytic Capacitors

![CP 6x11mm](https://github.com/dhaillant/kicad-3dmodels/raw/master/Capacitors_Radial_THT/CP_Radial_D6.3mm_L11.0mm_P2.50mm.png)


Generated with https://github.com/dhaillant/kicad-3d-models-in-freecad

Dimensions based on Nichicon UVZ series (https://www.nichicon.co.jp/english/products/pdfs/e-uvz.pdf)
